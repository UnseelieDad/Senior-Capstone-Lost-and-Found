db_username = "admin"
db_password = "thispasswordisalotbetter"
db_name = "LnF"