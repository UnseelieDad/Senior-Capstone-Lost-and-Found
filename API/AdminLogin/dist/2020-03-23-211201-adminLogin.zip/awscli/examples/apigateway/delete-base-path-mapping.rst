**To delete a base path mapping for a custom domain name**

Command::

  aws apigateway delete-base-path-mapping --domain-name 'api.domain.tld' --base-path 'dev'
