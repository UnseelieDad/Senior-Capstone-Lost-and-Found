**To delete a lifecycle hook**

This example deletes the specified lifecycle hook::

    aws autoscaling delete-lifecycle-hook --lifecycle-hook-name my-lifecycle-hook --auto-scaling-group-name my-auto-scaling-group
